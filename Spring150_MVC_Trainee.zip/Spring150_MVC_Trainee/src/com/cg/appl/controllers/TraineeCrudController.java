package com.cg.appl.controllers;

import java.util.ArrayList;
import java.util.List;

import javax.annotation.PostConstruct;
import javax.annotation.Resource;
import javax.validation.Valid;

import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.cg.appl.entities.Trainee;
import com.cg.appl.exceptions.TraineeExceptions;
import com.cg.appl.services.TraineeServices;

@Controller
public class TraineeCrudController {
	private TraineeServices services;
	private List<String> domainList;
	private List<String> locations;
	
	@PostConstruct
	public void initialize(){
		domainList=new ArrayList<>();
		domainList.add("java");
		domainList.add("dotnet");
		domainList.add("Database");
		domainList.add("Analytics");
		
		locations=new ArrayList<>();	
		locations.add("Mumbai");
		locations.add("Pune");
		locations.add("Bengaluru");
		locations.add("kolkata");
		locations.add("Delhi");
		
		
	}
	
	@Resource(name="traineeService")
	public void setTraineeServices(TraineeServices services){
		this.services=services;
	}
	
	@RequestMapping("/welcome.do")
	public ModelAndView getWelcomePage(){
		ModelAndView model=new ModelAndView("welcome");
		return model;
	}
	
	
	@RequestMapping("/enterTraineeNo.do")
	public ModelAndView enterTraineeNo(){
		System.out.println("In controlling method");
		ModelAndView model=new ModelAndView("enterTraineeNo");
		return model;
	}
	
	
	@RequestMapping("/getTraineeDetails.do")
	public ModelAndView getTraineeDetails(@RequestParam("traineeNo") int traineeNo){
		System.out.println("in controlling bmethod get trainee details" +traineeNo);
		ModelAndView model=null;
		try {
			Trainee trainee=services.getTraineeDetails(traineeNo);
			model = new ModelAndView("traineeDetails");
			model.addObject("traineeDetails",trainee);
		} catch (TraineeExceptions e) {
			//e.printStackTrace();
			model=new ModelAndView("error");
			model.addObject("errMsg",e.getMessage());
		}
	
		return model;
		
		
	}
	@RequestMapping("/listAllTrainees.do")
	public ModelAndView listAlltrainees(){
		ModelAndView model=null;
		try {
			List<Trainee> trainees=services.getAllTrainees();
			model = new ModelAndView("listAllTrainees");
			 model.addObject("trainees",trainees);
		} catch (TraineeExceptions e) {
			
			//e.printStackTrace();
			model=new ModelAndView("error");
			model.addObject("errMsg",e.getMessage());
		}
		 return model;
		
	}
	
	@RequestMapping("/entryForm.do")
	public ModelAndView getEntryForm(){
		ModelAndView model=new ModelAndView("entryForm");
		
		model.addObject("trainee", new Trainee());
		model.addObject("domains",domainList);
		model.addObject("locations",locations);
		return model;
	}
	
	@RequestMapping("/submitEntryForm.do")
	public ModelAndView submitEntryForm(@ModelAttribute @Valid Trainee trainee,BindingResult result){
		ModelAndView model=new ModelAndView("successInsert");
		if(result.hasErrors()){
			model.setViewName("entryForm");
			return model;
			
		}
		try {
			Trainee traineeResponse=services.insertNewTrainee(trainee);
			
			model.setViewName("successInsert");
			model.addObject("trainee", traineeResponse);
		} catch (TraineeExceptions e) {
		//	e.printStackTrace();
			model=new ModelAndView("error");
			model.addObject("errMsg", "Record insertion failed"+ e.getMessage());
		}
		return model;
	}
	
	
	@RequestMapping("/updateTrainee.do")
	public ModelAndView updateTrainee(@RequestParam("id") int traineeNo){
		System.out.println("in controlling bmethod get trainee details" +traineeNo);
		
		ModelAndView model=null;
		model=new ModelAndView("error");
		model.addObject("errMsg","Dummy Message");
		/*try {
			Trainee trainee=services.getTraineeDetails(traineeNo);
			model = new ModelAndView("traineeDetails");
			model.addObject("traineeDetails",trainee);
		} catch (TraineeExceptions e) {
			//e.printStackTrace();
			model=new ModelAndView("error");
			model.addObject("errMsg",e.getMessage());
		}*/
	
		return model;
		
		
	}
	
}
