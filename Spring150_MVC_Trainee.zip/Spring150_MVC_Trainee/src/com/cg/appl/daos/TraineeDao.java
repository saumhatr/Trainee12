package com.cg.appl.daos;

import java.util.List;

import com.cg.appl.entities.Trainee;
import com.cg.appl.exceptions.TraineeExceptions;

public interface TraineeDao {
	Trainee getTraineeDetails(int traineeId) throws TraineeExceptions;
	List<Trainee> getAllTrainees() throws TraineeExceptions;
	Trainee insertNewTrainee(Trainee trainee) throws TraineeExceptions;
}
